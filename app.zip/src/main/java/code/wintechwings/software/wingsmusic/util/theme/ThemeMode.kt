package code.wintechwings.software.wingsmusic.util.theme

enum class ThemeMode {
    LIGHT,
    DARK,
    BLACK,
    AUTO
}