package code.wintechwings.software.wingsmusic.fragments.artists

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import code.wintechwings.software.wingsmusic.Result
import code.wintechwings.software.wingsmusic.model.Artist
import code.wintechwings.software.wingsmusic.providers.RepositoryImpl
import kotlinx.coroutines.launch

class ArtistViewModel(application: Application) : AndroidViewModel(application) {
    var artists = MutableLiveData<List<Artist>>()

    init {
        loadArtists()
    }

    fun loadArtists() = viewModelScope.launch {
        val result = RepositoryImpl(getApplication()).allArtists()
        if (result is Result.Success) {
            artists.value = result.data
        } else {
            artists.value = listOf()
        }
    }
}