
package code.wintechwings.software.wingsmusic.fragments.settings

import android.content.res.ColorStateList
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.annotation.StringRes
import androidx.fragment.app.Fragment
import code.wintechwings.software.appthemehelper.ThemeStore
import code.wintechwings.software.wingsmusic.App
import code.wintechwings.software.wingsmusic.R
import code.wintechwings.software.wingsmusic.activities.SettingsActivity
import code.wintechwings.software.wingsmusic.extensions.hide
import code.wintechwings.software.wingsmusic.extensions.show
import code.wintechwings.software.wingsmusic.util.NavigationUtil
import kotlinx.android.synthetic.main.fragment_main_settings.*

class MainSettingsFragment : Fragment(), View.OnClickListener {
    override fun onClick(view: View) {
        when (view.id) {
            R.id.generalSettings -> inflateFragment(
                ThemeSettingsFragment(),
                R.string.general_settings_title
            )
            R.id.audioSettings -> inflateFragment(AudioSettings(), R.string.pref_header_audio)
            R.id.nowPlayingSettings -> inflateFragment(
                NowPlayingSettingsFragment(),
                R.string.now_playing
            )
            R.id.personalizeSettings -> inflateFragment(
                PersonalizeSettingsFragment(),
                R.string.personalize
            )
            R.id.imageSettings -> inflateFragment(
                ImageSettingFragment(),
                R.string.pref_header_images
            )
            R.id.notificationSettings -> inflateFragment(
                NotificationSettingsFragment(),
                R.string.notification
            )
            R.id.otherSettings -> inflateFragment(OtherSettingsFragment(), R.string.others)
            R.id.aboutSettings -> NavigationUtil.goToAbout(requireActivity())
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_main_settings, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        generalSettings.setOnClickListener(this)
        audioSettings.setOnClickListener(this)
        nowPlayingSettings.setOnClickListener(this)
        personalizeSettings.setOnClickListener(this)
        imageSettings.setOnClickListener(this)
        notificationSettings.setOnClickListener(this)
        otherSettings.setOnClickListener(this)
        aboutSettings.setOnClickListener(this)

        buyProContainer.apply {
            if (!App.isProVersion()) show() else hide()
            setOnClickListener {
                NavigationUtil.goToProVersion(requireContext())
            }
        }
        buyPremium.setOnClickListener {
            NavigationUtil.goToProVersion(requireContext())
        }
        ThemeStore.accentColor(requireContext()).let {
            buyPremium.setTextColor(it)
            diamondIcon.imageTintList = ColorStateList.valueOf(it)
        }
    }

    companion object {

    }

    private fun inflateFragment(fragment: Fragment, @StringRes title: Int) {
        (requireActivity() as SettingsActivity).setupFragment(fragment, title)
    }
}