package code.wintechwings.software.wingsmusic.fragments.albums

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import code.wintechwings.software.wingsmusic.Result
import code.wintechwings.software.wingsmusic.model.Album
import code.wintechwings.software.wingsmusic.providers.RepositoryImpl
import kotlinx.coroutines.launch

class AlbumViewModel(application: Application) : AndroidViewModel(application) {
    var albums = MutableLiveData<List<Album>>()

    init {
        getAlbums()
    }

    fun getAlbums() = viewModelScope.launch {
        val result = RepositoryImpl(getApplication()).allAlbums()
        if (result is Result.Success) {
            albums.value = result.data
        }else {
            albums.value = listOf()
        }
    }
}