
package code.wintechwings.software.wingsmusic.fragments.genres

import android.os.Bundle
import android.view.View
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import code.wintechwings.software.wingsmusic.App
import code.wintechwings.software.wingsmusic.R
import code.wintechwings.software.wingsmusic.adapter.GenreAdapter
import code.wintechwings.software.wingsmusic.fragments.base.AbsLibraryPagerRecyclerViewFragment
import code.wintechwings.software.wingsmusic.interfaces.MainActivityFragmentCallbacks

class GenresFragment : AbsLibraryPagerRecyclerViewFragment<GenreAdapter, LinearLayoutManager>(),
    MainActivityFragmentCallbacks {

    lateinit var genreViewModel: GenreViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        App.musicComponent.inject(this)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        genreViewModel = ViewModelProvider(this).get(GenreViewModel::class.java)
        genreViewModel.genres.observe(viewLifecycleOwner, Observer { genres ->
            if (genres.isNotEmpty()) {
                adapter?.swapDataSet(genres)
            } else {
                adapter?.swapDataSet(listOf())
            }
        })
    }

    override fun handleBackPress(): Boolean {
        return false
    }

    override fun createLayoutManager(): LinearLayoutManager {
        return LinearLayoutManager(activity)
    }

    override fun createAdapter(): GenreAdapter {
        val dataSet = if (adapter == null) ArrayList() else adapter!!.dataSet
        return GenreAdapter(mainActivity, dataSet, R.layout.item_list_no_image)
    }

    override val emptyMessage: Int
        get() = R.string.no_genres

    override fun onMediaStoreChanged() {
        genreViewModel.loadGenre()
    }

    companion object {
        @JvmField
        val TAG: String = GenresFragment::class.java.simpleName

        @JvmStatic
        fun newInstance(): GenresFragment {
            return GenresFragment()
        }
    }
}