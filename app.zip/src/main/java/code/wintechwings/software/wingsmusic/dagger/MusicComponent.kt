
package code.wintechwings.software.wingsmusic.dagger

import code.wintechwings.software.wingsmusic.activities.*
import code.wintechwings.software.wingsmusic.dagger.module.AppModule
import code.wintechwings.software.wingsmusic.dagger.module.PresenterModule
import code.wintechwings.software.wingsmusic.fragments.albums.AlbumsFragment
import code.wintechwings.software.wingsmusic.fragments.artists.ArtistsFragment
import code.wintechwings.software.wingsmusic.fragments.genres.GenresFragment
import code.wintechwings.software.wingsmusic.fragments.home.BannerHomeFragment
import code.wintechwings.software.wingsmusic.fragments.playlists.PlaylistsFragment
import code.wintechwings.software.wingsmusic.fragments.songs.SongsFragment
import dagger.Component
import javax.inject.Singleton

@Singleton
@Component(
    modules = [
        AppModule::class,
        PresenterModule::class
    ]
)
interface MusicComponent {

    fun inject(songsFragment: SongsFragment)

    fun inject(albumsFragment: AlbumsFragment)

    fun inject(artistsFragment: ArtistsFragment)

    fun inject(genresFragment: GenresFragment)

    fun inject(playlistsFragment: PlaylistsFragment)

    fun inject(artistDetailActivity: ArtistDetailActivity)

    fun inject(albumDetailsActivity: AlbumDetailsActivity)

    fun inject(playlistDetailActivity: PlaylistDetailActivity)

    fun inject(genreDetailsActivity: GenreDetailsActivity)

    fun inject(searchActivity: SearchActivity)

    fun inject(bannerHomeFragment: BannerHomeFragment)
}
