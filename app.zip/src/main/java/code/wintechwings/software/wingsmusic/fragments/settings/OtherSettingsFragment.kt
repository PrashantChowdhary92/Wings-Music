
package code.wintechwings.software.wingsmusic.fragments.settings

import android.os.Bundle
import android.view.View
import androidx.preference.Preference

import code.wintechwings.software.wingsmusic.R
import code.wintechwings.software.wingsmusic.preferences.MaterialListPreference

class OtherSettingsFragment : AbsSettingsFragment() {
    override fun invalidateSettings() {
        val languagePreference: MaterialListPreference = findPreference("language_name")!!
        languagePreference.setOnPreferenceChangeListener { _, _ ->
            requireActivity().recreate()
            return@setOnPreferenceChangeListener true
        }
    }

    override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
        addPreferencesFromResource(R.xml.pref_advanced)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val preference: Preference = findPreference("last_added_interval")!!
        setSummary(preference)
        val languagePreference: Preference = findPreference("language_name")!!
        setSummary(languagePreference)
    }
}
